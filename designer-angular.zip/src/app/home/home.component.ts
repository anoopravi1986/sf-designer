import { Component } from '@angular/core';
import $ from 'jquery';
declare var FancyProductDesigner: any;
@Component({
  selector: 'app-home',
  imports: [],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss'
})
export class HomeComponent {
  productId : string | undefined;

  constructor() {
  }
	ngAfterViewInit(){
    setTimeout(() => {
    	$(document).ready(function(){

        var $yourDesigner = $('#clothing-designer'),
          pluginOpts = {
            stageWidth: 1200,
                        stageHeight: 600,
                        initialActiveModule: "products",
                        toolbarPlacement: "inside-top",
                        mainBarModules: ['products', 'images', 'text', 'designs', 'manage-layers', 'manage-layerss', 'productss'],
                        editorMode: false,
                        smartGuides: true,
                        fonts: [{
                            name: 'Helvetica'
                        }, {
                            name: 'Times New Roman'
                        }, {
                            name: 'Arial'
                        }, {
                            name: 'Lobster',
                            url: 'google'
                        }, {
                            name: 'LSANS',
                            url: '../../assets/css/fonts/lsans_0-webfont.ttf'
                        }, {
                            name: 'Monsteraat',
                            url: '../../assets/fonts/Montserrat-Light.ttf'
                        }],
                        customTextParameters: {
                            colors: false,
                            removable: true,
                            resizable: true,
                            draggable: true,
                            rotatable: true,
                            autoCenter: true,
                            boundingBox: "Base"
                        },
                        customImageParameters: {
                            draggable: true,
                            removable: true,
                            resizable: true,
                            rotatable: true,
                            colors: '#000',
                            autoCenter: true,
                            boundingBox: "Base"
                        },
                        actions: {
                            'top': ['undo', 'redo', 'download', 'share', 'print', 'save', 'preview-lightbox', 'paste'],
                            'right': ['manage-layers', 'magnify-glass', 'zoom', 'reset-product', 'qr-code', 'ruler'],
                            'bottom': ['undo', 'redo'],
                            'left': []
                        },
                        selectedColor: "#f5f5f5",
                        boundingBoxColor: "#005ede",
                        outOfBoundaryColor: "#990000",
                        cornerIconColor: "#000000",
        },
        

        yourDesigner = new FancyProductDesigner($yourDesigner, pluginOpts);

        //print button
      $('#print-button').click(function(){
        yourDesigner.print();
        return false;
      });


      });
    })
	}
}
